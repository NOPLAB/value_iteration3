// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xvi_sweep.h"

extern XVi_sweep_Config XVi_sweep_ConfigTable[];

#ifdef SDT
XVi_sweep_Config *XVi_sweep_LookupConfig(UINTPTR BaseAddress) {
	XVi_sweep_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XVi_sweep_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XVi_sweep_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XVi_sweep_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVi_sweep_Initialize(XVi_sweep *InstancePtr, UINTPTR BaseAddress) {
	XVi_sweep_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVi_sweep_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVi_sweep_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XVi_sweep_Config *XVi_sweep_LookupConfig(u16 DeviceId) {
	XVi_sweep_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XVI_SWEEP_NUM_INSTANCES; Index++) {
		if (XVi_sweep_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XVi_sweep_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVi_sweep_Initialize(XVi_sweep *InstancePtr, u16 DeviceId) {
	XVi_sweep_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVi_sweep_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVi_sweep_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

