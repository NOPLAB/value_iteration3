// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XVI_SWEEP_STREAM_H
#define XVI_SWEEP_STREAM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xvi_sweep_stream_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XVi_sweep_stream_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XVi_sweep_stream;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XVi_sweep_stream_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XVi_sweep_stream_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XVi_sweep_stream_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XVi_sweep_stream_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XVi_sweep_stream_Initialize(XVi_sweep_stream *InstancePtr, UINTPTR BaseAddress);
XVi_sweep_stream_Config* XVi_sweep_stream_LookupConfig(UINTPTR BaseAddress);
#else
int XVi_sweep_stream_Initialize(XVi_sweep_stream *InstancePtr, u16 DeviceId);
XVi_sweep_stream_Config* XVi_sweep_stream_LookupConfig(u16 DeviceId);
#endif
int XVi_sweep_stream_CfgInitialize(XVi_sweep_stream *InstancePtr, XVi_sweep_stream_Config *ConfigPtr);
#else
int XVi_sweep_stream_Initialize(XVi_sweep_stream *InstancePtr, const char* InstanceName);
int XVi_sweep_stream_Release(XVi_sweep_stream *InstancePtr);
#endif

void XVi_sweep_stream_Start(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_IsDone(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_IsIdle(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_IsReady(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_EnableAutoRestart(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_DisableAutoRestart(XVi_sweep_stream *InstancePtr);

void XVi_sweep_stream_Set_value_table(XVi_sweep_stream *InstancePtr, u64 Data);
u64 XVi_sweep_stream_Get_value_table(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_value_table_rd(XVi_sweep_stream *InstancePtr, u64 Data);
u64 XVi_sweep_stream_Get_value_table_rd(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_penalty_table(XVi_sweep_stream *InstancePtr, u64 Data);
u64 XVi_sweep_stream_Get_penalty_table(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_trans_table(XVi_sweep_stream *InstancePtr, u64 Data);
u64 XVi_sweep_stream_Get_trans_table(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_map_x(XVi_sweep_stream *InstancePtr, u32 Data);
u32 XVi_sweep_stream_Get_map_x(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_map_y(XVi_sweep_stream *InstancePtr, u32 Data);
u32 XVi_sweep_stream_Get_map_y(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_Set_cu_id(XVi_sweep_stream *InstancePtr, u32 Data);
u32 XVi_sweep_stream_Get_cu_id(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_Get_max_delta(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_Get_max_delta_vld(XVi_sweep_stream *InstancePtr);

void XVi_sweep_stream_InterruptGlobalEnable(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_InterruptGlobalDisable(XVi_sweep_stream *InstancePtr);
void XVi_sweep_stream_InterruptEnable(XVi_sweep_stream *InstancePtr, u32 Mask);
void XVi_sweep_stream_InterruptDisable(XVi_sweep_stream *InstancePtr, u32 Mask);
void XVi_sweep_stream_InterruptClear(XVi_sweep_stream *InstancePtr, u32 Mask);
u32 XVi_sweep_stream_InterruptGetEnabled(XVi_sweep_stream *InstancePtr);
u32 XVi_sweep_stream_InterruptGetStatus(XVi_sweep_stream *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
