// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xvi_sweep_stream.h"

extern XVi_sweep_stream_Config XVi_sweep_stream_ConfigTable[];

#ifdef SDT
XVi_sweep_stream_Config *XVi_sweep_stream_LookupConfig(UINTPTR BaseAddress) {
	XVi_sweep_stream_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XVi_sweep_stream_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XVi_sweep_stream_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XVi_sweep_stream_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVi_sweep_stream_Initialize(XVi_sweep_stream *InstancePtr, UINTPTR BaseAddress) {
	XVi_sweep_stream_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVi_sweep_stream_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVi_sweep_stream_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XVi_sweep_stream_Config *XVi_sweep_stream_LookupConfig(u16 DeviceId) {
	XVi_sweep_stream_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XVI_SWEEP_STREAM_NUM_INSTANCES; Index++) {
		if (XVi_sweep_stream_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XVi_sweep_stream_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVi_sweep_stream_Initialize(XVi_sweep_stream *InstancePtr, u16 DeviceId) {
	XVi_sweep_stream_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVi_sweep_stream_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVi_sweep_stream_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

