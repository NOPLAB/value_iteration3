// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xvi_sweep_stream.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XVi_sweep_stream_CfgInitialize(XVi_sweep_stream *InstancePtr, XVi_sweep_stream_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XVi_sweep_stream_Start(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL) & 0x80;
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XVi_sweep_stream_IsDone(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XVi_sweep_stream_IsIdle(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XVi_sweep_stream_IsReady(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XVi_sweep_stream_EnableAutoRestart(XVi_sweep_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XVi_sweep_stream_DisableAutoRestart(XVi_sweep_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_AP_CTRL, 0);
}

void XVi_sweep_stream_Set_value_table(XVi_sweep_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_DATA, (u32)(Data));
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_DATA + 4, (u32)(Data >> 32));
}

u64 XVi_sweep_stream_Get_value_table(XVi_sweep_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_DATA);
    Data += (u64)XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_DATA + 4) << 32;
    return Data;
}

void XVi_sweep_stream_Set_value_table_rd(XVi_sweep_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_RD_DATA, (u32)(Data));
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_RD_DATA + 4, (u32)(Data >> 32));
}

u64 XVi_sweep_stream_Get_value_table_rd(XVi_sweep_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_RD_DATA);
    Data += (u64)XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_VALUE_TABLE_RD_DATA + 4) << 32;
    return Data;
}

void XVi_sweep_stream_Set_penalty_table(XVi_sweep_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_PENALTY_TABLE_DATA, (u32)(Data));
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_PENALTY_TABLE_DATA + 4, (u32)(Data >> 32));
}

u64 XVi_sweep_stream_Get_penalty_table(XVi_sweep_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_PENALTY_TABLE_DATA);
    Data += (u64)XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_PENALTY_TABLE_DATA + 4) << 32;
    return Data;
}

void XVi_sweep_stream_Set_trans_table(XVi_sweep_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_TRANS_TABLE_DATA, (u32)(Data));
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_TRANS_TABLE_DATA + 4, (u32)(Data >> 32));
}

u64 XVi_sweep_stream_Get_trans_table(XVi_sweep_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_TRANS_TABLE_DATA);
    Data += (u64)XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_TRANS_TABLE_DATA + 4) << 32;
    return Data;
}

void XVi_sweep_stream_Set_map_x(XVi_sweep_stream *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAP_X_DATA, Data);
}

u32 XVi_sweep_stream_Get_map_x(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAP_X_DATA);
    return Data;
}

void XVi_sweep_stream_Set_map_y(XVi_sweep_stream *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAP_Y_DATA, Data);
}

u32 XVi_sweep_stream_Get_map_y(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAP_Y_DATA);
    return Data;
}

void XVi_sweep_stream_Set_cu_id(XVi_sweep_stream *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_CU_ID_DATA, Data);
}

u32 XVi_sweep_stream_Get_cu_id(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_CU_ID_DATA);
    return Data;
}

u32 XVi_sweep_stream_Get_max_delta(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAX_DELTA_DATA);
    return Data;
}

u32 XVi_sweep_stream_Get_max_delta_vld(XVi_sweep_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_MAX_DELTA_CTRL);
    return Data & 0x1;
}

void XVi_sweep_stream_InterruptGlobalEnable(XVi_sweep_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_GIE, 1);
}

void XVi_sweep_stream_InterruptGlobalDisable(XVi_sweep_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_GIE, 0);
}

void XVi_sweep_stream_InterruptEnable(XVi_sweep_stream *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_IER);
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_IER, Register | Mask);
}

void XVi_sweep_stream_InterruptDisable(XVi_sweep_stream *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_IER);
    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_IER, Register & (~Mask));
}

void XVi_sweep_stream_InterruptClear(XVi_sweep_stream *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVi_sweep_stream_WriteReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_ISR, Mask);
}

u32 XVi_sweep_stream_InterruptGetEnabled(XVi_sweep_stream *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_IER);
}

u32 XVi_sweep_stream_InterruptGetStatus(XVi_sweep_stream *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XVi_sweep_stream_ReadReg(InstancePtr->Control_BaseAddress, XVI_SWEEP_STREAM_CONTROL_ADDR_ISR);
}

